const osfunction = require('./osmodule')
const pathmodule = require('./pathmodule')

osfunction()

pathmodule()